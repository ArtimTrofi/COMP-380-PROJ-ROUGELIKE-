using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharScript : MonoBehaviour
{
    [Range(1,12)]
    public float moveSpeed = 6F;
    public float maxHealth = 15F;
    public float baseDamage = 1f;

    public Rigidbody2D charRigidbody;
    
    public HealthbarBehaviour healthbarControl;
    public Canvas canvas;

    public Animator charAnim;

    public int currentWeaponIndex;
    //[SerializeField]
    public GameObject currentGun;
    //[SerializeField]
    public GameObject[] firearms;

    public bool alive;

    public Text currWeaponText;

    // Start is called before the first frame update
    void Start()
    {
        currWeaponText.text = "Pistol";
        alive = true;
        //healthbar stuff
        healthbarControl = GetComponent<HealthbarBehaviour>();
        healthbarControl.MaxHitpoints = maxHealth;
        Canvas currCanvas = Instantiate(canvas);
        healthbarControl.ManualStart(currCanvas);
        currCanvas.GetComponent<SliderController>().ManualStart(gameObject);


        charAnim = GetComponent<Animator>();
        charRigidbody = GetComponent<Rigidbody2D>();


        currentWeaponIndex = 0;
        currentGun = Instantiate(firearms[0], transform.position, transform.rotation, gameObject.transform); //position should be a bit different, based on character's facing tbh.

    }


    // Update is called once per frame
    void Update()
    {
        if (alive)
        {
            move();

            swapWeapon();


            if (Input.GetMouseButton(0))
            {
                Debug.Log("base damage: " + baseDamage);
                currentGun.GetComponent<Weapon>().Fire(baseDamage);
                Debug.Log("Firing " + currentGun.name);
            }


            //Transform.LookAt(Transform target)  might do this more easily
            //gun rotation/aiming. Will need to adjust to pivot around the character's hand, and change the character's facing based on mouse position
            Vector2 mousePosition;
            mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 aimDirection = mousePosition - charRigidbody.position;
            float aimAngle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg - 90f;
            float currAngle = Mathf.Atan2(currentGun.transform.rotation.y, currentGun.transform.rotation.x) * Mathf.Rad2Deg - 90f;
            //currentGun.transform.rotation = Quaternion.FromToRotation(currentGun.transform.forward, new Vector3(0, 0, aimAngle));
            //currentGun.transform.Rotate(0, 0, aimAngle, Space.World);
            currentGun.transform.rotation = Quaternion.Euler(0, 0, (aimAngle - currAngle) + 90f);
        }

    }



    private void move()
    {
        charRigidbody.velocity = new Vector2(0, 0); //resets velocity to 0 if none of the keys are held down

        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
        {
            charRigidbody.velocity = new Vector2(-1 * moveSpeed, charRigidbody.velocity.y);
            charAnim.Play("LeftRun");
            transform.localScale = new Vector3(1, 1, 1);
        }
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
        {
            charRigidbody.velocity = new Vector2(1 * moveSpeed, charRigidbody.velocity.y);
            charAnim.Play("LeftRun");
            transform.localScale = new Vector3(-1, 1, 1);

        }
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        {
            charRigidbody.velocity = new Vector2(charRigidbody.velocity.x, 1 * moveSpeed);
            if (charRigidbody.velocity.x == 0)
                charAnim.Play("UpwardRun");
        }
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        {
            charRigidbody.velocity = new Vector2(charRigidbody.velocity.x, -1 * moveSpeed);
            if (charRigidbody.velocity.x == 0)
                charAnim.Play("DownwardRun");
        }

        //normalize diagonal movement (so it's not faster than cardinal movement)
        if (charRigidbody.velocity.magnitude > moveSpeed)  //should maybe also check if hitting a wall, to avoid dragging/reducing speed when moving diagonally against a wall.
        {
            charRigidbody.velocity = charRigidbody.velocity.normalized * moveSpeed; //approx root2 of x and y velocities
        }
        //Debug.Log("char velocity: " + charRigidbody.velocity);

        if (charRigidbody.velocity.magnitude == 0)
        {
            charAnim.Play("Idle");
        }
    }

    public void swapWeapon()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            // next weapon
            if (currentWeaponIndex < firearms.Length - 1)
            {
                currentWeaponIndex += 1;
            }
            else
            {
                currentWeaponIndex = 0;
            }
            Destroy(currentGun);
            currentGun = Instantiate(firearms[currentWeaponIndex], transform.position, transform.rotation, gameObject.transform);
            currWeaponText.text = currentGun.name;
        }
        if (Input.GetKeyDown(KeyCode.Q))
        {
            // previous weapon
            if (currentWeaponIndex > 0)
            {
                currentWeaponIndex -= 1;
            }
            else
            {
                currentWeaponIndex = firearms.Length - 1;
            }
            Destroy(currentGun);
            currentGun = Instantiate(firearms[currentWeaponIndex], transform.position, transform.rotation, gameObject.transform);
            currWeaponText.text = currentGun.name;
        }
    }

}
