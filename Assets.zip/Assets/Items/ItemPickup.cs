using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    //Boosts are additive, Multipliers are multiplicative

    //These values will actually be determined in the Inspector of each item.
    public float healthBoost;
    public float attackBoost; //add this much damage to player base damage.
    public float attackMultiplier = 1;  //(could have it apply to only your currently equipped weapon, to upgrade that specific weapon)
    public float moveSpeedMultiplier = 1;   //if we want to boost movespeed

    private bool pickedUp; //set to true on first player collision, so player can't grab multiple times if we play a pick-up animation

    // Start is called before the first frame update
    void Start()
    {
        pickedUp = false;
    }

    // Update is called once per frame
    void Update()
    {
        //maybe floating animation. might just have playAnim in Start() then tho.
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && !pickedUp)
        {

            pickedUp = true;
            CharScript playerStats = collision.gameObject.GetComponent<CharScript>();


            collision.gameObject.GetComponent<HealthbarBehaviour>().addHealth(healthBoost);
            playerStats.baseDamage += attackBoost;
            playerStats.baseDamage *= attackMultiplier;
            playerStats.moveSpeed *= moveSpeedMultiplier;

            Debug.Log("destroy me OOOO");
            Destroy(gameObject); 
            //Destroy(gameObject, 1f); //to destroy after 1 second
            //and play pick-up animation
            //and maybe briefly display some floating text about what the item did (+health, +damage, +movespeed, etc)
        }
    }

}
