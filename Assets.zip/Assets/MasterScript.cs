using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MasterScript : MonoBehaviour
{
    public Text roomText;

    public RoomGenerationScript roomGenerator;
    public GameObject currentRoom;
    public int roomCount;

    public GameObject playerChar;
    public CharScript playerCharScript;


    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("master script start");

        roomCount = 0;
        roomGenerator = GameObject.Find("RoomGenerator").GetComponent<RoomGenerationScript>();
        //playerChar = GameObject.Find("PlayerCharacter");
        playerCharScript = GameObject.Find("PlayerCharacter").GetComponent<CharScript>();

        currentRoom = roomGenerator.generateRoom(roomCount);
    }

    // Update is called once per frame
    void Update()
    {

    }


    //deletes current room and generates new room.
    public void moveToNewRoom()
    {
        Destroy(currentRoom);
        roomCount++;
        currentRoom = roomGenerator.generateRoom(roomCount);
        roomText.text = "Room " + roomCount.ToString();
    }
}
