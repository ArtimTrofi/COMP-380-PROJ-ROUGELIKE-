using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoomScript : MonoBehaviour
{

    //arrays of the various enemy prefabs
    public GameObject[] meleeEnemyTypes;
    public GameObject[] rangedEnemyTypes;
    public GameObject[] bossEnemyTypes;

    public GameObject[] lootTable;
    private int randLootNum;
    public int lootCount;

    public bool roomCleared;
    public int enemyCount;


    public Canvas canvas; //prefab to pair with each enemy spawned


    void Start()
    {
        enemyCount = 0;
        spawnEnemies();
        roomCleared = false;
    }

    void Update()
    {
        
        if (enemyCount <= 0 && !roomCleared)
        {
            roomCleared = true;

            transform.Find("Grid").transform.Find("Exit").GetComponent<DoorExitScript>().Open(); //unlock exit door

            for (int i = 0; i < lootCount; i++)
            {
                randLootNum = Random.Range(0, lootTable.Length - 1);
                Instantiate(lootTable[randLootNum], transform.Find("LootDropPoint").transform.position + new Vector3(.3f*i, 0, 0), transform.rotation); //drop loot
            }  
        }
    }


    private void spawnEnemies()
    {
        //for each enemySpawn in room
            //instantiate enemy (with this room as its parent)
            //instantiate canvas
            //set canvas to follow enemy
            //set healthbarBehaviour script's Healthbar to the canvas

        Transform spawnList = transform.Find("EnemySpawnPoints");
        Transform currSpawn;
        GameObject currEnemy;
        Canvas currCanvas;
        int rand;

        for (int i = 0; i < spawnList.childCount; i++)
        {
            currSpawn = spawnList.GetChild(i);

            if (currSpawn.name == "melee")
            {
                rand = Random.Range(0, meleeEnemyTypes.Length);
                currEnemy = Instantiate(meleeEnemyTypes[rand], currSpawn.position, transform.rotation, gameObject.transform);
                currCanvas = Instantiate(canvas);
                currCanvas.GetComponent<SliderController>().ManualStart(currEnemy);
                currEnemy.GetComponent<HealthbarBehaviour>().ManualStart(currCanvas);
            }
            else if (currSpawn.name == "ranged")
            {
                rand = Random.Range(0, rangedEnemyTypes.Length);
                currEnemy = Instantiate(rangedEnemyTypes[rand], currSpawn.position, transform.rotation, gameObject.transform);
                currCanvas = Instantiate(canvas);
                currCanvas.GetComponent<SliderController>().ManualStart(currEnemy);
                currEnemy.GetComponent<HealthbarBehaviour>().ManualStart(currCanvas);
            }
            else if (currSpawn.name == "ranged2")
            {
                currEnemy = Instantiate(rangedEnemyTypes[1], currSpawn.position, transform.rotation, gameObject.transform);
                currCanvas = Instantiate(canvas);
                currCanvas.GetComponent<SliderController>().ManualStart(currEnemy);
                currEnemy.GetComponent<HealthbarBehaviour>().ManualStart(currCanvas);
            }
            else if (currSpawn.name == "boss1")
            {
                currEnemy = Instantiate(bossEnemyTypes[0], currSpawn.position, transform.rotation, gameObject.transform);
                currCanvas = Instantiate(canvas);
                currCanvas.GetComponent<SliderController>().ManualStart(currEnemy);
                //RectTransform rt = currCanvas.GetComponent<RectTransform>();
                //rt.sizeDelta = new Vector2(100, 100);
                currEnemy.GetComponent<HealthbarBehaviour>().ManualStart(currCanvas);
            }
            else
            {
                currEnemy = Instantiate(meleeEnemyTypes[0], currSpawn.position, transform.rotation, gameObject.transform);
                currCanvas = Instantiate(canvas);
                currCanvas.GetComponent<SliderController>().ManualStart(currEnemy);
                currEnemy.GetComponent<HealthbarBehaviour>().ManualStart(currCanvas);
            }

            enemyCount++;
        }
        Debug.Log("Spawned " + enemyCount + " enemies in room.");

    }

    /*    
     *    
    //might go in RoomScript, which would manage clearing of a room and stuff.
    //loot table
    public class Room
    {
        private int lootRarity;
        private int lootSize;

        //will change what is given when making a room. for now just placeholder data types
        public Room(int givenLootRarity, int givenLootSize)
        {


            lootRarity = givenLootRarity;
            lootSize = givenLootSize;

        }

        //called when room is cleared.
        public void getLoot()
        {
            int count = lootSize;

            while (count > 0)
            {
                dropItem(); //will need to set up items to push away from each other when they spawn/are dropped. or spawn/drop them adjacent to each other
                count--;
            }
        }

        //drops a random item based on given rarity possibility
        private void dropItem()
        {
            if (lootRarity == 1)
            {
                //common-rare loot
            }
            else if (lootRarity == 2)
            {
                //rare loot
            }
            else if (lootRarity == 3)
            {
                //common-legendary loot
            }
            else if (lootRarity == 4)
            {
                //rare-legendary loot
            }
            else if (lootRarity >= 5)
            {
                //legendary loot
            }
            else
            {
                //something. dirt. idk.
            }

        }


        public int getLootRarity()
        {
            return lootRarity;
        }
        public int getLootSize()
        {
            return lootSize;
        }

    }

    */
}
