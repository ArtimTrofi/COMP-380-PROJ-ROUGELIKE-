using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class DoorExitScript : MonoBehaviour
{
    private bool isOpen;
    public MasterScript master;

    public Sprite unlockedSprite;
    public Tilemap exitTilemap;

    // Start is called before the first frame update
    void Start()
    {
        isOpen = false;
        master = GameObject.Find("Master").GetComponent<MasterScript>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    //called on clearing a room
    public void Open()
    {
        GetComponent<TilemapCollider2D>().isTrigger = true;
        //maybe play an animation of the door opening. or just swap out the door sprite for an open/unlocked door
        isOpen = true;
        Debug.Log("Door unlocked");
        //exitTilemap.GetTile(new Vector3Int(0, 0, 0)).GetTileData().sprite = unlockedSprite;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            if (isOpen)
            {
                master.moveToNewRoom();
            }
            else
            {
                Debug.Log("Door is locked.");
                //could display a message/text for the player in game
            }
            
        }
    }


}

