using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class RoomGenerationScript : MonoBehaviour
{

    public int floorCount = 0; //level or floor. will increment on moving to next floor (likely on clearing a boss room)

    private Vector3 newPosition; //position the character will be snapped to on generation of a new room. determined by doorEntrance, or "5" in the room arrays

    public GameObject[] tilemapRoomArray;

    public GameObject playerChar;
    public CharScript playerCharScript;

    private int lastRoom;


    void Awake()
    {
        Debug.Log("room generator online");

        newPosition = new Vector3(0, 0, 0);

        playerChar = GameObject.Find("PlayerCharacter");
        playerCharScript = GameObject.Find("PlayerCharacter").GetComponent<CharScript>();
    }



    public Vector3 getNewPosition()
    {
        return newPosition;
    }


    public GameObject generateRoom(int roomCount)
    {
        //IMPLEMENT SOMETHING SO IT WON'T REPEAT ROOMS, maybe even for a few rooms.
 
        playerChar.GetComponent<Rigidbody2D>().MovePosition(new Vector2(0, 0));  //throwaway position, out of the way to avoid invonvenient collisions at generation of a new room


        //random selection of room
        int randRoomNum;
        int attempts = 0;
        if (floorCount == 0) //tutorial room
        {
            randRoomNum = 0;
        }
        else if (floorCount == 1)
        {
            randRoomNum = Random.Range(1, tilemapRoomArray.Length); //adjust the range for floor 1
            while (randRoomNum == lastRoom && attempts < 20) //so it doesn't repeat rooms. attempts there to stop infinite loop
            {
                randRoomNum = Random.Range(1, tilemapRoomArray.Length);
                attempts++;
            }
        }
        else
        {
            randRoomNum = Random.Range(1, tilemapRoomArray.Length); //adjust the range for floor 2, etc
            while (randRoomNum == lastRoom && attempts < 20) //so it doesn't repeat rooms. attempts there to stop infinite loop
            {
                randRoomNum = Random.Range(1, tilemapRoomArray.Length);
                attempts++;
            }
        }
        lastRoom = randRoomNum;


        Debug.Log("generating tilemap room " + randRoomNum);


        //instantiating a room prefab
        GameObject currentRoom = Instantiate(tilemapRoomArray[randRoomNum], new Vector3(0, 0, 0), transform.rotation);


        //snap player to new position
        newPosition = currentRoom.transform.GetChild(1).transform.position; //(1) is EntrancePoint, for now
        playerChar.GetComponent<Rigidbody2D>().MovePosition(new Vector2(newPosition.x, newPosition.y));


        //thing to remove all stray projectiles on entering a new room. Didn't work as is. Might've messed other things up as well.
        //GameObject.FindGameObjectWithTag("Projectile").GetComponent<Projectile>().changedRooms = true;
        //Projectile.changedRooms = true;
        
        
        if (roomCount % 5 == 0)
        {
            floorCount++;
        }

        return currentRoom;
    }




}
