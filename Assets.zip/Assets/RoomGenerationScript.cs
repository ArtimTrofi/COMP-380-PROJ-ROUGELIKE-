using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class RoomGenerationScript : MonoBehaviour
{
    public int roomCount = 0; //# of completed rooms. Tracking because after X rooms, next will automatically be a boss room. Might increment it somewhere else. (maybe in master script? or room script? since it'd increment on clearing a room)
    private Vector3 newPosition; //position the character will be snapped to on generation of a new room. determined by doorEntrance, or "5" in the room arrays

    private int level = 1; //level or floor. will increment on moving to next floor (likely on clearing a boss room)

    //prefabs. placed into Inspector for RoomGenerator object.
    public GameObject emptyTile; //0
    public GameObject floor; //1
    public GameObject wall; //2
    public GameObject door; //3
    public GameObject doorExit; //4
    public GameObject doorEntrance; //5

    public Sprite[] tileSprites;

    public GameObject roomPrefab;

    public GameObject[] tilemapRoomArray;

    //set of arrays, each array is a room, represented by a set of tiles, each tile represented by an int
    //the array set-up is maybe a bit clunky for larger rooms/zones though. A bit difficult to keep track of/read through. Maybe not an issue if rooms don't get giga-massive.
    private int[][] normalRoomSet = new int[][] 
    {
        new int[] //room 0
        {19, 11, //19x11
         2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2
        },
        new int[] //room 1 
        {19, 11, //19x11
         2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2
        },
        new int[] //room 2   
        {30, 15, //30x15
         2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 2, 2, 2, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2
        },
        new int[] //room 3   
        {13, 35, //13x35
         2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
         2, 2, 2, 2, 2, 2, 5, 2, 2, 2, 2, 2, 2
        },
        new int[] //room 4   
        {20, 35, //20x35
         2, 2, 2, 2, 2, 2, 4, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0, 0, 0,
         2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0,
         0, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0,
         0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0, 0,
         0, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0,
         0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 0, 0, 0, 0, 0,
         0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0,
         0, 0, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0,
         0, 0, 0, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0,
         0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0,
         0, 0, 0, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0,
         0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 0, 0, 0,
         0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0,
         0, 0, 0, 0, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0,
         0, 0, 0, 0, 0, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0,
         0, 0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0,
         0, 0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0,
         0, 0, 0, 0, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 0, 0,
         0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 
         0, 0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0,
         0, 0, 0, 2, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0,
         0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0,
         0, 0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0,
         0, 0, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 0, 0, 0, 0,
         0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0,
         0, 0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0,
         0, 2, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0,
         0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0, 0, 
         0, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 
         2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 0, 0, 0, 0, 0, 0,
         2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 0, 0, 0, 0, 0, 0, 0,
         2, 2, 2, 2, 2, 2, 5, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0
        }
    };




    void Awake()
    {
        Debug.Log("room generator online");
        //shouldn't have these statements for prefabs.
          //emptyTile = GameObject.Find("Tile_Blank");
          //floorMarble1 = GameObject.Find("Tile_Floor_Marble_1");
          //floorMarble2 = GameObject.Find("Tile_Floor_Marble_2");
          //wallMarble1 = GameObject.Find("Tile_Wall_Marble_1");
          //doorMarble1 = GameObject.Find("Tile_Door_Marble_1");


        //currentRoom = GameObject.Find("CurrentRoom");  from when CurrentRoom was a GameObject in the scene, not a prefab
        newPosition = new Vector3(0, 0, 0);
        //newPosition = currentRoom.transform.position;  from when CurrentRoom was a GameObject in the scene, not a prefab
    }



    //called from masterScript?
    //selects and fills out a random room from roomSet, unless roomCount indicates a boss should be next
    //moves room to appropriate spot for player?
    public GameObject generateRoom()
    {
        //IMPLEMENT SOMETHING SO IT WON'T REPEAT ROOMS, maybe even for a few rooms.
        //random selection of room
        int randRoomNum = Random.Range(0, normalRoomSet.Length);
        int[] selectedTileSet = normalRoomSet[randRoomNum];

        //Room newRoom = new Room((roomCount + 1) % 5, 3, randRoomNum, normalRoomSet[randRoomNum]); //lootRarity, lootSize, enemySet, tileSet

        GameObject currentRoom = Instantiate(roomPrefab, new Vector3(0, 0, 0), transform.rotation);

        Debug.Log("generating room " + randRoomNum);

        float xPointer = 0;
        float yPointer = 0;
        float sideLength = 1f;

        

        int baseRowLength = selectedTileSet[0]; //row length, given by 1st int in the selected room's array
        int baseColLength = selectedTileSet[1]; //col length, given by 2nd int in the selected room's array
        int currTileIndex = 2; //position in a room's tile array. starting from 3rd int in the selected room's array
        int numRows = (selectedTileSet.Length - 2) / baseRowLength;
        int numCols = (selectedTileSet.Length - 2) / baseColLength;

        //nested for loop to place the tiles
        for (int row = 0; row < numRows; row++) //row
        {
            for (int col = 0; col < numCols; col++) //col
            {
                setTile(selectedTileSet[currTileIndex], new Vector3(xPointer, yPointer, 0), sideLength, currentRoom);
                currTileIndex++;
                //currTile = selectTile(selectedRoom[currTileIndex]);
                //Instantiate(currTile, new Vector3(xPointer, yPointer, 0), transform.rotation, GameObject.Find("CurrentRoom").transform); // Instantiate(object to instantiate, position, rotation, its parent)
                xPointer += sideLength;
            }
            xPointer -= numCols * sideLength;
            yPointer -= sideLength;
        }
        Debug.Log("finished generating");

        //snap the position such that the player character is "entering" at the appropriate spot.
        //moveRoom(currentRoom);

        return currentRoom;

        //set a new GameObject? Room? new instance of Room? as currentRoom? generateRoom() returns Room? set currentRoom = generateRoom() in masterScript?
        
    }

    //instantiates a tile (type depending on the int representation (from selectedRoom array) at given position
    private void setTile(int tileNum, Vector3 currPosition, float sideLength, GameObject currentRoom)
    {
        //Debug.Log("placing tile at: " + currPosition.ToString());
        GameObject currentTile;

        //bunch of if statements determining which tile to place
        if (tileNum == 1)
        {
            //Debug.Log("placing floor");
            currentTile = Instantiate(floor, currentRoom.transform); // Instantiate(object to instantiate, position, rotation, its parent)  or Instantiate(object to instantiate, parent)
            currentTile.transform.position = currPosition;
            //might move the sprite setting into its own function, once several options/floors are set up
            if (level == 1)
            {
                currentTile.GetComponent<SpriteRenderer>().sprite = tileSprites[1];
                //Debug.Log("floor sprite should have been changed");
            }
            else if (level == 2)
            {

            }
        }
        else if (tileNum == 2)
        {
            currentTile = Instantiate(wall, currentRoom.transform); // Instantiate(object to instantiate, position, rotation, its parent)
            currentTile.transform.position = currPosition;
            //might move the sprite setting into its own function, once several options/floors are set up
            if (level == 1)
            {
                currentTile.GetComponent<SpriteRenderer>().sprite = tileSprites[2];
            }
        }
        else if (tileNum == 3)
        {
            currentTile = Instantiate(door, currentRoom.transform); // Instantiate(object to instantiate, position, rotation, its parent)
            currentTile.transform.position = currPosition;
            //might move the sprite setting into its own function, once several options/floors are set up
            if (level == 1)
                currentTile.GetComponent<SpriteRenderer>().sprite = tileSprites[3];
        }
        else if (tileNum == 4)
        {
            currentTile = Instantiate(doorExit, currentRoom.transform); // Instantiate(object to instantiate, position, rotation, its parent)
            currentTile.transform.position = currPosition;
            //might move the sprite setting into its own function, once several options/floors are set up
            if (level == 1)
                currentTile.GetComponent<SpriteRenderer>().sprite = tileSprites[4];
        }
        else if (tileNum == 5)
        {
            currentTile = Instantiate(doorEntrance, currentRoom.transform); // Instantiate(object to instantiate, position, rotation, its parent)
            currentTile.transform.position = currPosition;
            //might move the sprite setting into its own function, once several options/floors are set up
            if (level == 1)
                currentTile.GetComponent<SpriteRenderer>().sprite = tileSprites[5];

            newPosition = currPosition + new Vector3(0, sideLength*1.5f, 0); //change later if we want entrances not on bottom of room. places player above entrance
        }
        else
        {
            currentTile = Instantiate(emptyTile, currPosition, transform.rotation, currentRoom.transform); // Instantiate(object to instantiate, position, rotation, its parent)
            currentTile.transform.position = currPosition;
            currentTile.GetComponent<SpriteRenderer>().sprite = tileSprites[0];
        }
    }

    //shift room such that player is at entrance. maybe make private, idk.
    public void moveRoom(GameObject currentRoom)
    {
        currentRoom.transform.position = Vector3.Scale(newPosition, new Vector3(-1, -1, -1));
    }

    //uses current floor to determine which sprite to set the tile to.
    private void setSprite(GameObject currentTile)
    {

    }

    public Vector3 getNewPosition()
    {
        return newPosition;
    }


    public GameObject generateTilemapRoom()
    {
        //IMPLEMENT SOMETHING SO IT WON'T REPEAT ROOMS, maybe even for a few rooms.
        //random selection of room
        int randRoomNum = Random.Range(0, tilemapRoomArray.Length);

        //Room newRoom = new Room((roomCount + 1) % 5, 3, randRoomNum, normalRoomSet[randRoomNum]); //lootRarity, lootSize, enemySet, tileSet

        Debug.Log("generating tilemap room " + randRoomNum);

        GameObject currentRoom = Instantiate(tilemapRoomArray[randRoomNum], new Vector3(0, 0, 0), transform.rotation);

        newPosition = currentRoom.transform.GetChild(1).transform.position; //(1) is EntrancePoint, for now

        Debug.Log("finished generating");

        //snap the position such that the player character is "entering" at the appropriate spot.
        //moveRoom(currentRoom);

        return currentRoom;

        //set a new GameObject? Room? new instance of Room? as currentRoom? generateRoom() returns Room? set currentRoom = generateRoom() in masterScript?

    }

}
