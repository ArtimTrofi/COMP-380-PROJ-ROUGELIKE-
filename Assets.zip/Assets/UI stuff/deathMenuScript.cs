using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class deathMenuScript : MonoBehaviour
{
    public void ReturnToMenu()
    {
        //Use Time.timeScale = 0; on the Start() function. And then when someone click the screen u can set it back to 1 and the game will start playing.
        SceneManager.LoadScene("menuScene");
    }

}
