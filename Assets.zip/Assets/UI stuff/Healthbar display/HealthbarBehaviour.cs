using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthbarBehaviour : MonoBehaviour
{
    public float Hitpoints;
    public float MaxHitpoints;
    public SliderController Healthbar;

    public void ManualStart(Canvas canvas)
    {
        Debug.Log(gameObject.name + " max hp: " + MaxHitpoints);
        Hitpoints = MaxHitpoints;
        Healthbar = canvas.GetComponent<SliderController>();
        Healthbar.SetHealth(Hitpoints, MaxHitpoints);
    }


    public void TakeHit(float damage)
    {
        Hitpoints -= damage;
        Healthbar.SetHealth(Hitpoints, MaxHitpoints);
        if (Hitpoints <= 0)
        {
            if (!gameObject.CompareTag("Player"))
            {
                Debug.Log("object with healthbar destroyed");
                Destroy(gameObject);
                //figure out why the camera is deleted when the player dies. Is the Destroy actually getting called on the PlayerCharacter?
            }
            else
            {
                Debug.Log("PLAYER set inactive and null");
                Healthbar.target = null;
                gameObject.GetComponent<CharScript>().alive = false;
                gameObject.GetComponent<CharScript>().charAnim.Play("Idle");
                gameObject.transform.Rotate(0, 0, 90, Space.Self);
                gameObject.transform.Find("Main Camera").transform.Rotate(0, 0, -90, Space.Self);
                //gameObject.SetActive(false);
                //switch to "dead" sprite
                //display game over screen
                //figure out why the camera is deleted. Is the Destroy actually getting called on the PlayerCharacter?
            }
        }
    }

    public void addHealth(float healValue)
    {
        Hitpoints += healValue;
        if (Hitpoints > MaxHitpoints)
        {
            Hitpoints = MaxHitpoints; //no overhealth yet
        }
        Healthbar.SetHealth(Hitpoints, MaxHitpoints);
    }
    
}

