using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// A slider is used as a healthbar and is coded to follow the gameObject (target).
public class SliderController : MonoBehaviour
{
    public Slider Slider;
    public Transform target;

    public Color Low;
    public Color High;
    public Vector3 Offset;
    


    public void ManualStart(GameObject pairedUnit)
    {
        target = pairedUnit.transform;
        Slider.transform.position = Camera.main.WorldToScreenPoint(target.position + Offset);
        //if (target == null)
        //{
        //    target = transform;
        //}
    }

    private void Update()
    {


        // Set the slider's position based on the target object's position plus the offset
        if (target != null)
        {
            //The following sets the sliders position to the transform of the target it is following.
            //Offset can be changed in the inspector to change posiiton of the slider away from the gameObject.
            Debug.Log("trying to move slider based on camera...");
            Slider.transform.position = Camera.main.WorldToScreenPoint(target.position + Offset);
        }
        else 
        {
            Debug.Log("Canvas has no target to follow and is trying to update. Will now be destroyed.");
            Destroy(gameObject);
            target = null;
            Slider.gameObject.SetActive(false);
            
        }
    }

    public void SetHealth(float health, float maxHealth)
    {
        // SetActive allows the healthbar to remain invisible until the gameObject takes damage.
        Slider.gameObject.SetActive(health < maxHealth);
        Slider.value = health;
        Slider.maxValue = maxHealth;

        //Changes the color of slider to a color between the chosen high and low healthbar colors.
        Slider.fillRect.GetComponentInChildren<Image>().color = Color.Lerp(Low, High, Slider.normalizedValue);

    }

    private void OnDestroy()
    {
        // If the target object is destroyed, set the target to null
        target = null;
        Debug.Log("Destroyed Canvas....");
    }
}