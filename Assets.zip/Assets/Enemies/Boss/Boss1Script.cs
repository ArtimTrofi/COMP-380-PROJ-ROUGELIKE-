using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Boss1Script : MonoBehaviour
{
    public Transform target;
    public float speed = 3f;
    public float rotateSpeed = 0.025f;
    private Rigidbody2D rb;

    public float fireRate;
    private float timeToFire;
    public GameObject bulletPrefab;

    public Transform firingPoint;

    private float maxHealth = 90f;

    public float collisionDamage = 8f;
    public float damage = 3f;

    public Transform anchor1;
    public Transform anchor2;
    public Transform anchor3;
    public Transform anchor4;

    int anchor = 1;

    private void Start()
    {
        GetComponent<HealthbarBehaviour>().MaxHitpoints = maxHealth;
        rb = GetComponent<Rigidbody2D>();
        //rb.isKinematic = true;

        timeToFire = 0f;

        anchor1 = GameObject.Find("anchor1").transform;
        anchor2 = GameObject.Find("anchor2").transform;
        anchor3 = GameObject.Find("anchor3").transform;
        anchor4 = GameObject.Find("anchor4").transform;

        GetTarget();
    }

    private void Update()
    {
        if (target)
        {
            RotateTowardsTarget();
        }

        if (target != null)
        {
            Shoot();
        }

    }

    private void Shoot()
    {
        GameObject bulletInstance;
        if (timeToFire <= 0f)
        {
            Debug.Log("Boss shooting");
            for (int i = 0; i < 2; i++)
            {
                //float aimAngle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg - 90f; //check which of the 4 directions player is closest in, and when line of sight is clear, shoot there.
                bulletInstance = Instantiate(bulletPrefab, new Vector3(firingPoint.position.x - .1f + .2f*i, firingPoint.position.y, firingPoint.position.z), firingPoint.rotation);
                bulletInstance.GetComponent<Projectile>().firedByEnemy = true;
                bulletInstance.GetComponent<Projectile>().damage = damage;
                bulletInstance.transform.localScale = new Vector3(bulletInstance.transform.localScale.x * 2f, bulletInstance.transform.localScale.y * 2f, bulletInstance.transform.localScale.z);
            }
            timeToFire = fireRate;
        }
        else
        {
            timeToFire -= Time.deltaTime;
        }
    }

    private void FixedUpdate()
    {

        switch (anchor)
        {
            case 1:
                rb.velocity = Vector3.MoveTowards(transform.position, anchor1.position, speed) - transform.position;
                Debug.Log("Boss velocity = " + rb.velocity);
                if (Vector3.Distance(transform.position, anchor1.position) <= .5f)
                    anchor = 2;
                break;
            case 2:
                rb.velocity = Vector3.MoveTowards(transform.position, anchor2.position, speed) - transform.position;
                if (Vector3.Distance(transform.position, anchor2.position) <= .5f)
                    anchor = 3;
                break;
            case 3:
                rb.velocity = Vector3.MoveTowards(transform.position, anchor3.position, speed) - transform.position;
                if (Vector3.Distance(transform.position, anchor3.position) <= .5f)
                    anchor = 4;
                break;
            case 4:
                rb.velocity = Vector3.MoveTowards(transform.position, anchor4.position, speed) - transform.position;
                if (Vector3.Distance(transform.position, anchor4.position) <= .5f)
                    anchor = 1;
                break;
            default:
                speed = 6f;
                transform.position = Vector3.MoveTowards(transform.position, target.position, speed); //move toward player
                break;
        }

        /*
        if (target != null)
        {
            if (Vector2.Distance(target.position, transform.position) >= minDistanceToStop)
            {
                rb.velocity = transform.up * speed;
            }
            else
            {
                rb.velocity = Vector2.zero;
            }
        }
        */


    }

    private void RotateTowardsTarget()
    {
        //transform.LookAt(target);
        //Transform.LookAt(Transform target)  might do this more easily. Eh. LookAt rotates on all 3 axes at once, so it'll pull some Paper Mario shit.

        Vector2 targetDirection = target.position - transform.position;
        float angle = Mathf.Atan2(targetDirection.y, targetDirection.x) * Mathf.Rad2Deg - 90f;
        Quaternion q = Quaternion.Euler(new Vector3(0, 0, angle));
        transform.localRotation = Quaternion.Slerp(transform.localRotation, q, rotateSpeed);
    }

    private void GetTarget()
    {
        if (GameObject.FindGameObjectWithTag("Player"))
        {
            target = GameObject.FindGameObjectWithTag("Player").transform;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Boss1 collided with Player");
            target.GetComponent<HealthbarBehaviour>().TakeHit(collisionDamage);
        }
    }

    private void OnDestroy()
    {
        // drop loot, decrement room's enemyCount
        Debug.Log(transform.name + " destroyed.");
        transform.parent.GetComponent<RoomScript>().enemyCount--;
    }

}
