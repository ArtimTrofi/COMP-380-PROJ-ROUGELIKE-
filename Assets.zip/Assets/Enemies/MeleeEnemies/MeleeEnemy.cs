using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeEnemy : MonoBehaviour
{
    public Transform target;
    public float speed = 3f;
    public float maxSpeed;
    public float rotateSpeed = 0.025f;
    public float damage = 2f;
    private Rigidbody2D rb;

    private void Start()
    {
        maxSpeed = speed;
        rb = GetComponent<Rigidbody2D>();
        GetTarget();
    }

    private void Update()
    {
        if (target)
        {
            RotateTowardsTarget();
        }

    }

    private void FixedUpdate()
    {
        //Move forwards
        rb.velocity = transform.up * speed;

        if (speed < maxSpeed)
        {
            speed += .02f;
        }

    }

    private void RotateTowardsTarget()
    {
        //Transform.LookAt(Transform target)  might do this more easily. Eh. LookAt rotates on all 3 axes at once, so it'll pull some Paper Mario shit.
        Vector2 targetDirection = target.position - transform.position;
        float angle = Mathf.Atan2(targetDirection.y, targetDirection.x) * Mathf.Rad2Deg - 90f;
        Quaternion q = Quaternion.Euler(new Vector3(0, 0, angle));
        transform.localRotation = Quaternion.Slerp(transform.localRotation, q, rotateSpeed);
    }

    private void GetTarget()
    {
        if (GameObject.FindGameObjectWithTag("Player"))
        {
            target = GameObject.FindGameObjectWithTag("Player").transform;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Melee Enemy collided with Player");
            //collision.takehit or whatever
            target.GetComponent<HealthbarBehaviour>().TakeHit(damage);
            bump(target);
            //Destroy(collision.gameObject);
            //target = null;
        }
    }

    private void bump(Transform recipient)
    {
        speed = 0;
        recipient.GetComponent<Rigidbody2D>().AddForce(transform.up * 20, ForceMode2D.Impulse);
    }


    private void OnDestroy()
    {
        // drop loot, decrement room's enemyCount
        Debug.Log(transform.name + " destroyed. source: MeleeEnemy");
        transform.parent.GetComponent<RoomScript>().enemyCount--;
    }

}
