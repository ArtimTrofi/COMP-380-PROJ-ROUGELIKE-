using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnifeMelee : MonoBehaviour
{
    public Transform attackPosition;
    public float attackRadius;
    public int maxObjectsHit = 5;
    public LayerMask selectObjectsToHit;
    public Collider2D[] objectsHit;
    public float damage;

    // Start is called before the first frame update
    void Start()
    {
        objectsHit = new Collider2D[maxObjectsHit];
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(1))
        {
            int numObjectsHit = Physics2D.OverlapCircleNonAlloc(attackPosition.position, attackRadius, objectsHit, selectObjectsToHit);
            if (numObjectsHit > 0)
            {
                for (int i = 0; i < numObjectsHit; i++)
                {
                    Collider2D hit = objectsHit[i];
                    HealthbarBehaviour healthbar = hit.GetComponent<HealthbarBehaviour>();
                    if (healthbar != null)
                    {
                        healthbar.TakeHit(damage);
                    }
                }
            }
        }
    }
}
