using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shotgun : Weapon
{ 
    public GameObject bulletPrefab;
    public Transform firePoint;
    //public float fireForce = 20f;

    public float fireRate = .4f;
    public float timeToFire = 0f;

    private int nonTargetLayer;

    public int bulletAmount;
    public float spread;
    //public float bulletSpeed = 24f;

    public override void Fire(float baseDamage)
    {
        
        timeToFire -= Time.deltaTime;

        if (Input.GetMouseButtonDown(0))
        {
            timeToFire = 0f;
        }

        if (timeToFire <= 0f)
        {
            timeToFire = fireRate;
            Debug.Log("Firing shotgun...");
            
            for (int i = 0; i < bulletAmount; i++)
            {
                GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
                bullet.transform.localScale = new Vector3(bullet.transform.localScale.x * .7f, bullet.transform.localScale.y * .7f, bullet.transform.localScale.z);
                bullet.GetComponent<Projectile>().damage *= baseDamage;

                bullet.GetComponent<Projectile>().setNonCollisionLayer(nonTargetLayer);

                //Can do random spread, but it just doesn't feel good to shoot. Random.Range(-spread, spread)
                //bullet.transform.rotation *= Quaternion.AngleAxis((i * 2 * spread / (bulletAmount - 1) - spread), Vector3.forward);
                bullet.transform.rotation *= Quaternion.AngleAxis(Random.Range(-spread, spread), Vector3.forward);
            }
            //bullet.GetComponent<Rigidbody2D>().AddForce(firePoint.up * fireForce, ForceMode2D.Impulse);
        }
        
    }

    public override void nonHit(int givenLayer)
    {
        nonTargetLayer = givenLayer;
    }

    public override string getName()
    {
        return "Shotgun";
    }
}

