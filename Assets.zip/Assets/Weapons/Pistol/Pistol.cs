using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pistol : Weapon
{

    public GameObject bulletPrefab;
    public Transform firePoint;

    public override void Fire(float baseDamage)
    {
        if (Input.GetMouseButtonDown(0)) //only fire on initial click
        {
            Debug.Log("Firing pistol...");
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            bullet.GetComponent<Projectile>().damage *= baseDamage;
        }

    }
}
