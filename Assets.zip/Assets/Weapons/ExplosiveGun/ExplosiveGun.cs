using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosiveGun : Weapon
{

    public GameObject ExplosiveAmmo;
    public Transform firePoint;
    //public float fireForce = 20f;

    private int nonTargetLayer;

    public override void Fire(float baseDamage)
    {
        if (Input.GetMouseButtonDown(0)) //only fire on initial click
        {
            Debug.Log("Firing explosive gun...");
            GameObject explosive = Instantiate(ExplosiveAmmo, firePoint.position, firePoint.rotation);
            explosive.GetComponent<Projectile>().damage *= baseDamage;
            //explosive.GetComponent<Rigidbody2D>().AddForce(firePoint.up * fireForce, ForceMode2D.Impulse);

            explosive.GetComponent<Projectile>().setNonCollisionLayer(nonTargetLayer);
        }

    }

    public override void nonHit(int givenLayer)
    {
        nonTargetLayer = givenLayer;
    }

    public override string getName()
    {
        return "Explosive Gun";
    }
}