using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RicochetGun : Weapon
{

    public GameObject ricochetBulletPrefab;
    public Transform firePoint;
        
    public override void Fire(float baseDamage)
    {
        if (Input.GetMouseButtonDown(0)) //only fire on initial click
        {
            Debug.Log("Firing ricochet gun...");
            GameObject ricochetBullet = Instantiate(ricochetBulletPrefab, firePoint.position, firePoint.rotation);
            ricochetBullet.GetComponent<Projectile>().damage *= baseDamage;
        }
    }
}
