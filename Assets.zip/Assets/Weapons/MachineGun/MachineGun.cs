using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MachineGun : Weapon
{

    public GameObject bulletPrefab;
    public Transform firePoint;
    public float fireRate = .2f;
    public float timeToFire = 0f;

    public override void Fire(float baseDamage)
    {
        Debug.Log("Firing machine gun...");
        
        if (Input.GetMouseButtonDown(0))
        {
            timeToFire = 0f;
        }

        if (timeToFire <= 0f)
        {
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            bullet.GetComponent<Projectile>().damage *= baseDamage;
            timeToFire = fireRate;
        }
        else
        {
            timeToFire -= Time.deltaTime;
        }

    }
}